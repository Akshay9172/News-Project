<?php $__env->startSection('heading'); ?>
    <div>
        <h3 class="card-title"><b> News List</b></h3>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="card-title">News</h3>
                <a href="<?php echo e(route('news.create')); ?>" class="btn btn-primary">Create News</a>
            </div>
            <form action="<?php echo e(route('news.list')); ?>" method="GET">
                <div class="row card-body">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="language_id">Language</label>
                            <select name="language_id" class="form-select" onchange="this.form.submit()">
                                <option value="">All Languages</option>
                                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($language->id); ?>"
                                        <?php echo e(request('language_id') == $language->id ? 'selected' : ''); ?>>
                                        <?php echo e($language->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="news_type">News Type</label>
                            <select name="news_type" class="form-select" onchange="this.form.submit()">
                                <option value="">All Types</option>
                                <option value="Breaking News"
                                    <?php echo e(request('news_type') == 'Breaking News' ? 'selected' : ''); ?>>
                                    Breaking
                                    News</option>
                                <option value="Normal News" <?php echo e(request('news_type') == 'Normal News' ? 'selected' : ''); ?>>
                                    Normal
                                    News
                                </option>
                                <option value="Video News" <?php echo e(request('news_type') == 'Video News' ? 'selected' : ''); ?>>
                                    Video
                                    News
                                </option>
                            </select>
                        </div>
                    </div>
                </div>
            </form>
            <div class="table-responsive">
                <table class="table card-table table-vcenter text-nowrap datatable">
                    <thead>
                        <tr>
                            <th>SR.NO</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>News Type</th>
                            <th>Status</th>
                            <th>Published On</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><span class="text-muted"><?php echo e($key + 1); ?></span></td>
                                <td><span class="text-reset"><b><?php echo e(Str::words($item->title, 9, '...')); ?></b></span></td>
                                <td><?php echo Str::limit($item->description, 50); ?></td>
                                <td><?php echo e($item->news_type); ?></td>
                                <td><?php echo e($item->status); ?></td>
                                <td><?php echo e($item->created_at); ?></td>
                                <td>
                                    <button type="button" class="btn btn-success" data-bs-toggle="modal"
                                        data-bs-target="#viewNewsModal" data-id="<?php echo e($item->id); ?>">View</button>
                                    <form action="<?php echo e(route('news.delete', $item->id)); ?>" method="POST"
                                        style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger"
                                            onclick="return confirm('Are you sure you want to delete this news?')">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="viewNewsModal" tabindex="-1" aria-labelledby="viewNewsModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewNewsModalLabel">News Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- News details will be loaded here dynamically using JavaScript -->
                </div>
                <div class="modal-footer">
                    <form action="<?php echo e(route('news.publish')); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="news_id" id="publish_news_id">
                        <button type="submit" class="btn btn-success">Publish</button>
                    </form>
                    <form action="<?php echo e(route('news.reject')); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="news_id" id="reject_news_id">
                        <button type="submit" class="btn btn-danger">Reject</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        // JavaScript to handle the modal
        var viewNewsModal = document.getElementById('viewNewsModal');
        viewNewsModal.addEventListener('show.bs.modal', function(event) {
            var button = event.relatedTarget;
            var newsId = button.getAttribute('data-id');

            // Make an AJAX request to fetch news details
            fetch(`/news/${newsId}`)
                .then(response => response.json())
                .then(data => {
                    var modalBody = viewNewsModal.querySelector('.modal-body');
                    modalBody.innerHTML = `
                        <h1>${data.title}</h1>
                        <img  src="${data.img}" alt="Image">
                        <p> ${data.description}</p>
                        <p><strong>News Type:</strong> ${data.news_type}</p>
                        <p><strong>Status:</strong> ${data.status}</p>
                        <p><strong>Published On:</strong> ${data.created_at}</p>
                    `;
                    document.getElementById('publish_news_id').value = newsId;
                    document.getElementById('reject_news_id').value = newsId;
                })
                .catch(error => console.error('Error:', error));
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\News App\News - Copy2\resources\views\Admin\Reporter\News\rejectNews.blade.php ENDPATH**/ ?>