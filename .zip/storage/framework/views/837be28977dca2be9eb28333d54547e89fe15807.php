<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row row-equal-height p-3">
            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-sm-6 mt-3">
                    <a href="/news/<?php echo e($single_news->id); ?>" class="card h-100">
                        <div class="card h-100">
                            <div class="row g-0 h-100">
                                <div class="col-md-6 col-sm-12">
                                    <div class="card-body">
                                        <p><?php echo e($single_news->category->name); ?></p>
                                        <p class="card-text"><?php echo Str::limit($single_news->description, 70); ?></p>
                                        <p class="card-text"><small class="text-muted"><i class="far fa-calendar-alt"></i>
                                                <?php echo e($single_news->created_at); ?></small></p>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-12 card-img-container">
                                    <img class="card-img-right img-fluid" src="<?php echo e($single_news->img); ?>" alt="Image">
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.userLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\News App\News - Copy2\resources\views/UI/All News Show/allNewsShow.blade.php ENDPATH**/ ?>