<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('UI.BreakingNews.breakingNews', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row mt-3">
            <div class="col-md-3">
                <div class="shine-effect">
                    <img src="https://templates.envytheme.com/sinmun/default/assets/img/2-ads.png" alt="Advertisement Image">
                </div>
            </div>
            <div class="col-md-9">
                <?php echo $__env->make('UI.LeatestNews.leatestNews', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('UI.Recent News.recentNews', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.userLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\News App\News - Copy2\resources\views/UI/Home/home.blade.php ENDPATH**/ ?>